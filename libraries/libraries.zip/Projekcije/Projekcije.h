#ifndef PROJEKCIJE_H
#define PROJEKCIJE_H
#include <stdint.h>

#define TILE_SIZE 256
#define EARTH_RADIUS 6378137
#define INITIAL_RESOLUTION 156543.03392804062
#define ORIGIN_SHIFT 20037508.342789244

#ifdef __cplusplus
extern "C" {
#endif

void CoordinatesToPixels(uint8_t zoom, double lat, double lng, int *px, int *py);
void CoordinatesToDisplayCoordinates(uint8_t zoom, double lat_center, double lng_center, double lat, double lng, int *px, int *py);

#ifdef __cplusplus
}
#endif


#endif
