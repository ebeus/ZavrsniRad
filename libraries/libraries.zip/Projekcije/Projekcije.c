#include "Projekcije.h"
#include "math.h"


#define degreesToRadians(angleDegrees) (angleDegrees * M_PI / 180.0)
#define radiansToDegrees(angleRadians) (angleRadians * 180.0 / M_PI)

void CoordinatesToPixels(uint8_t zoom, double lat, double lng, int *px, int *py) {
  lat = degreesToRadians(lat);
  lng = degreesToRadians(lng);

  *px = (int)(128.0/M_PI)*pow(2, zoom)*(lng+M_PI);
  *py = (int)(128.0/M_PI)*pow(2, zoom)*(M_PI - log(tan(M_PI/4+lat/2)));
}

void CoordinatesToDisplayCoordinates(uint8_t zoom, double lat_center, double lng_center, double lat, double lng, int *px, int *py) {
  int px_c, py_c;
  int px_t, py_t;

  CoordinatesToPixels(zoom,lat_center,lng_center,&px_c,&py_c);
  CoordinatesToPixels(zoom,lat,lng,&px_t, &py_t);

  *px = -px_t+px_c+160;
  *py = -py_t+py_c+120;
}
