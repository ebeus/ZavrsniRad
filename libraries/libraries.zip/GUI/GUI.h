#ifndef GUI_H
#define GUI_H

#include "Energia.h"
#include <TFTv2.h>
#include <avr/pgmspace.h>
#include <TinyGPS++.h>
#include <JPEGDecoder.h>
#include <ArduinoJson.h>

class GUI {
private:
    const char* Naslov PROGMEM = "Zavrsni rad";
    const char* BTN_M_Stations PROGMEM = "Stations";
    const char* BTN_M_GPSInfo PROGMEM = "GPS Info";
    const char* BTN_M_Map PROGMEM = "Map";
    const char* Potpis PROGMEM = "ETF-Sarajevo Beus Ervin (2017)";

    const char* LBL_LAT PROGMEM = "Latitude:";
    const char* LBL_LNG PROGMEM = "Longitude:";
    const char* LBL_ALT PROGMEM = "Altitude:";
    const char* LBL_SPEED PROGMEM = "Speed(km/h):";
    const char* LBL_COURSE PROGMEM = "Course:";
    const char* LBL_SAT PROGMEM = "Satellite no.:";

    const char* LBL_NO_FIX PROGMEM = "NO FIX";

    const char* LBL_APRS_NAME PROGMEM = "Name:";
    const char* LBL_APRS_TYPE PROGMEM = "Type:";
    const char* LBL_APRS_COMMENT PROGMEM = "Comment:";
    const char* LBL_APRS_JSON_EMPTY PROGMEM = "Not found";

    const char* LBL_APRS_LASTTIME PROGMEM = "Last time:";
    const char* LBL_APRS_SRCCALL PROGMEM = "Src call:";


    const uint16_t y_dist = 40;
    const uint16_t rect_w = 260;

    void renderJPEG(int xpos, int ypos);

public:
    void begin(uint8_t csPin, uint8_t dcPin, uint8_t blPin, uint8_t rstPin);
    void ClearScreen();
    void DrawMainScreen(uint8_t selected);
    void DrawGPSInfo(TinyGPSPlus &gps);
    void DrawAprsList(const JsonObject& root);
    void DrawAprsInfo(const JsonObject& root, uint8_t item);
    void RenderImage(unsigned char *jpegFile, uint32_t size, int xpos, int ypos);
    void RenderImage(const unsigned char *jpegFile, unsigned int size, int xpos, int ypos);
    void DrawSymbol(uint8_t zoom, double lat_c, double lng_c, double lat, double lng,   const char* aprs_symbol, const char *name);
    void DrawString(const char *string,uint16_t poX, uint16_t poY, uint16_t size,uint16_t fgcolor, uint16_t bgcolor);
    void DisplayError(const char *error);
    void DrawIndicator(int x, int y, uint16_t color, bool clear, uint16_t bg_color);
    void DrawCenter(uint16_t color);
};

#endif
