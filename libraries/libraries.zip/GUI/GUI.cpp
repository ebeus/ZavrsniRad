#include "Energia.h"
#include <TFTv2.h>
#include <TinyGPS++.h>
#include <avr/pgmspace.h>
#include <JPEGDecoder.h>
#include <ArduinoJson.h>
#include "GUI.h"

#include "Simboli.h"
#include "Projekcije.h"

#define minimum(a,b)     (((a) < (b)) ? (a) : (b))

void GUI::begin(uint8_t csPin, uint8_t dcPin, uint8_t blPin, uint8_t rstPin) {
    Tft.begin(csPin, dcPin, blPin, rstPin);              // CS,DC,BL,RESET
    Tft.TFTinit();
    Tft.backlight_on();
    Tft.setRotation(1);
}

void GUI::ClearScreen() {
    Tft.fillScreen();
}

void GUI::DrawMainScreen(uint8_t selected) {

    Tft.fillScreen();
    Tft.fillRectangle(0,0,320,35,HEADER_COLOR);
    Tft.drawString(Naslov,100,5,2,WHITE,HEADER_COLOR);

    if(selected == 1) {
        Tft.drawRectangle(30,50,260,30,SELECTED);
        Tft.drawString(BTN_M_Stations,120,55,2,TEXT_COLOR,SELECTED);
    } else {
        Tft.drawRectangle(30,50,260,30,GRAY2);
        Tft.drawString(BTN_M_Stations,120,55,2,WHITE,BLACK);
    }

    if(selected == 2) {
        Tft.drawRectangle(30,90,260,30,SELECTED);
        Tft.drawString(BTN_M_GPSInfo,120,95,2,TEXT_COLOR,SELECTED);
    } else {
        Tft.drawRectangle(30,90,260,30,GRAY2);
        Tft.drawString(BTN_M_GPSInfo,120,95,2,WHITE,BLACK);
    }

    if(selected == 3) {
        Tft.drawRectangle(30,130,260,30,SELECTED);
        Tft.drawString(BTN_M_Map,120,135,2,TEXT_COLOR,SELECTED);
    } else {
        Tft.drawRectangle(30,130,260,30,GRAY2);
        Tft.drawString(BTN_M_Map,120,135,2,WHITE,BLACK);
    }


    Tft.fillRectangle(0,230,320,10,FOOTER_COLOR);
    Tft.drawString(Potpis,130,230,1,WHITE,FOOTER_COLOR);
}

void GUI::DrawGPSInfo(TinyGPSPlus &gps) {
    Tft.fillRectangle(0,0,320,35,HEADER_COLOR);
    Tft.drawString(BTN_M_GPSInfo,110,5,2,WHITE,HEADER_COLOR);

    if(gps.location.isValid() && gps.location.age() < 10000) {
        Tft.drawString(LBL_LAT,20,50,2,GRAY1,BLACK);
        Tft.drawFloat(gps.location.lat(),6,150,50,2,WHITE,BLACK);

        Tft.drawString(LBL_LNG,20,80,2,GRAY1,BLACK);
        Tft.drawFloat(gps.location.lng(),6,150,80,2,WHITE,BLACK);

        Tft.drawHorizontalLine(0,102,320,CYAN);

        Tft.drawString(LBL_ALT,20,110,2,GRAY1,BLACK);
        Tft.drawFloat(gps.altitude.meters(),2,150,110,2,WHITE,BLACK);

        Tft.drawString(LBL_SPEED,20,140,2,GRAY1,BLACK);
        Tft.drawFloat(gps.speed.kmph(),2,170,140,2,WHITE,BLACK);

        Tft.drawString(LBL_COURSE,20,170,2,GRAY1,BLACK);
        Tft.drawFloat(gps.course.deg(),4,150,170,2,WHITE,BLACK);


    } else {
        Tft.drawString(LBL_NO_FIX,120,110,2,BLACK,RED);
    }
}

/*
void GUI::DrawAprsList(const char *name, const char *type, const char *comment,int x, int y) {
    Tft.fillScreen();
    Tft.drawString(LBL_APRS_NAME, x,y,2, GRAY1, BLACK);
    Tft.drawString(name, x+60,y,2, GRAY1, BLACK);

    Tft.drawString(LBL_APRS_TYPE,x,y+20,1 , GRAY1, BLACK);
    Tft.drawString(type, x+50 ,y+20,1 , GRAY1,BLACK);

    Tft.drawString(LBL_APRS_COMMENT, x,y+30,1, GRAY1, BLACK);
    Tft.drawString(comment,x+50, y+30,1, GRAY1, BLACK);

    Tft.drawHorizontalLine(0,y+40,320, WHITE);

}*/

void GUI::DrawAprsList(const JsonObject &root) {
    uint8_t found = root["found"];
    uint16_t x = 10;
    uint16_t y = 10;

    Tft.fillScreen();

    if(!found) {
        DisplayError(LBL_APRS_JSON_EMPTY);
        return;
    }

    for(uint8_t i= 0; i < found; i++) {
        Tft.drawString(LBL_APRS_NAME, x,y+=10,1, WHITE, BLACK);
        Tft.drawString(root["entries"][i]["name"], x+60,y,1, WHITE, BLACK);
        Tft.drawString(LBL_APRS_TYPE,x,y+=10,1 , GRAY1, BLACK);
        Tft.drawString(root["entries"][i]["type"], x+50 ,y,1 , GRAY1,BLACK);
        Tft.drawString(LBL_APRS_COMMENT, x,y+=10,1, GRAY1, BLACK);
        Tft.drawString(root["entries"][i]["comment"],x+50, y,1, GRAY1, BLACK);
        y+=20;
    }
}

void GUI::DrawAprsInfo(const JsonObject& root, uint8_t item) {
    Tft.fillScreen();
    uint8_t found = root["found"];

    if(!found) {
        DisplayError(LBL_APRS_JSON_EMPTY);
        return;
    }

    if(found < item || item < 0) {
        DisplayError("Prekoraceno");
        return;
    }

    Tft.drawString(LBL_APRS_NAME,10,10,1,GRAY1,BLACK);
    Tft.drawString(root["entries"][item]["name"],80,10,1,GRAY1,BLACK);

    Tft.drawString(LBL_APRS_TYPE,10,30,1,GRAY1,BLACK);
    Tft.drawString(root["entries"][item]["type"],80,30,1,GRAY1,BLACK);

    Tft.drawString(LBL_APRS_LASTTIME,10,50,1,GRAY1,BLACK);
    Tft.drawString(root["entries"][item]["lasttime"],80,50,1,GRAY1,BLACK);

    Tft.drawString(LBL_LAT,10,90,1,GRAY1,BLACK);
    Tft.drawString(root["entries"][item]["lat"],80,90,1,GRAY1,BLACK);

    Tft.drawString(LBL_LNG,10,110,1,GRAY1,BLACK);
    Tft.drawString(root["entries"][item]["lng"],80,110,1,GRAY1,BLACK);

    Tft.drawString(LBL_APRS_SRCCALL,10,130,1,GRAY1,BLACK);
    Tft.drawString(root["entries"][item]["srccall"],80,130,1,GRAY1,BLACK);
}

void GUI::RenderImage(unsigned char *jpegFile, uint32_t size, int xpos = 0, int ypos = 0) {
    Tft.setRotation(1);
    JpegDec.decodeArray(jpegFile, size);
    uint16_t *pImg;
    uint16_t mcu_w = JpegDec.MCUWidth;
    uint16_t mcu_h = JpegDec.MCUHeight;
    uint32_t max_x = JpegDec.width;
    uint32_t max_y = JpegDec.height;

    uint32_t min_w = minimum(mcu_w, max_x % mcu_w);
    uint32_t min_h = minimum(mcu_h, max_y % mcu_h);

    uint32_t win_w = mcu_w;
    uint32_t win_h = mcu_h;

    uint32_t drawTime = millis();

    while(JpegDec.read()) {
        // save a pointer to the image block
        pImg = JpegDec.pImage;

        // calculate where the image block should be drawn on the screen
        int mcu_x = JpegDec.MCUx * mcu_w + xpos;
        int mcu_y = JpegDec.MCUy * mcu_h + ypos;

        // check if the image block size needs to be changed for the right and bottom edges
        if(mcu_x + mcu_w <= max_x)
            win_w = mcu_w;
        else
            win_w = min_w;

        if (mcu_y + mcu_h <= max_y)
            win_h = mcu_h;
        else
            win_h = min_h;

        // calculate how many pixels must be drawn
        uint32_t mcu_pixels = win_w * win_h;

        if((mcu_x + win_w) <= Tft.Width() && ( mcu_y + win_h) <= Tft.Height()) {
            Tft.setAddrWindow(mcu_x, mcu_y, mcu_x + win_w - 1, mcu_y + win_h - 1);
            Tft.WRITE_Package(pImg, mcu_pixels);
        }

        // stop drawing blocks if the bottom of the screen has been reached
        // the abort function will close the file
        else if ((mcu_y + win_h) >= Tft.Height())
            JpegDec.abort();
  }

}


void GUI::RenderImage(const unsigned char *jpegFile, unsigned int size, int xpos, int ypos) {
    JpegDec.decodeArray(jpegFile, size);
   // retrieve infomration about the image
  uint16_t *pImg;
  uint16_t mcu_w = JpegDec.MCUWidth;
  uint16_t mcu_h = JpegDec.MCUHeight;
  uint32_t max_x = JpegDec.width;
  uint32_t max_y = JpegDec.height;

  // Jpeg images are draw as a set of image block (tiles) called Minimum Coding Units (MCUs)
  // Typically these MCUs are 16x16 pixel blocks
  // Determine the width and height of the right and bottom edge image blocks
  uint32_t min_w = minimum(mcu_w, max_x % mcu_w);
  uint32_t min_h = minimum(mcu_h, max_y % mcu_h);

  // save the current image block size
  uint32_t win_w = mcu_w;
  uint32_t win_h = mcu_h;

  // record the current time so we can measure how long it takes to draw an image
//  uint32_t drawTime = millis();

  // save the coordinate of the right and bottom edges to assist image cropping
  // to the screen size
  max_x += xpos;
  max_y += ypos;

  // read each MCU block until there are no more
  while ( JpegDec.read()) {

    // save a pointer to the image block
    pImg = JpegDec.pImage;

    // calculate where the image block should be drawn on the screen
    int mcu_x = JpegDec.MCUx * mcu_w + xpos;
    int mcu_y = JpegDec.MCUy * mcu_h + ypos;


    // check if the image block size needs to be changed for the right and bottom edges
    if (mcu_x + mcu_w <= max_x) win_w = mcu_w;
    else win_w = min_w;
    if (mcu_y + mcu_h <= max_y) win_h = mcu_h;
    else win_h = min_h;


    // calculate how many pixels must be drawn
    uint32_t mcu_pixels = win_w * win_h;


    if ( ( mcu_x + win_w) <= Tft.Width() && ( mcu_y + win_h) <= Tft.Height()) {
          Tft.setAddrWindow(mcu_x, mcu_y, mcu_x + win_w - 1, mcu_y + win_h - 1);
          Tft.WRITE_Package(pImg,mcu_pixels);
    }

    // stop drawing blocks if the bottom of the screen has been reached
    // the abort function will close the file
    else if ( ( mcu_y + win_h) >= Tft.Height()) JpegDec.abort();  //240

  }

}


void GUI::DrawSymbol(uint8_t zoom, double lat_c, double lng_c, double lat, double lng, const char* aprs_symbol, const char *name) {
    int px=-1,py=-1;
    CoordinatesToDisplayCoordinates(zoom, lat_c, lng_c,lat, lng, &px, &py);
    char sym = aprs_symbol[0];
    if((px < 0 || px > 320) || (py < 0 || py > 240))    //ne crtati simbole izvan opsega
      return;

    if(!strncmp(aprs_symbol,"/r",2)) {
      RenderImage(antena_jpg, antena_jpg_len, px-10, py-10);
    } else if(!strncmp(aprs_symbol,"/>",2)) {
        RenderImage(auto_jpg, auto_jpg_len, px-10, py-10);
    } else if(aprs_symbol[1] == '0') {
      RenderImage(grey_circle_jpg, grey_circle_jpg_len, px-10, py-10);
      Tft.drawChar(sym,px-5,py-5,1,WHITE,GRAY1);

    } else if(aprs_symbol[1] == '&') {
      RenderImage(black_diamond_jpg, black_diamond_jpg_len, px-10, py-10);
      Tft.drawChar(sym,px-5,py-5,1,WHITE,BLACK);
    } else if(strncmp(aprs_symbol,"/_",2)) {

    } else {
      Tft.fillCircle(px,py,10,YELLOW);
    }

    DrawString(name,px,py+12,1, WHITE ,TEXT_BACKGROUND);

}

void GUI::DrawCenter(uint16_t color) {
    Tft.fillCircle(160,120,5,color);
}
void GUI::DrawString(const char *string,uint16_t poX, uint16_t poY, uint16_t size,uint16_t fgcolor, uint16_t bgcolor) {
    Tft.drawString(string,poX,poY,size,fgcolor,bgcolor);
}

void GUI::DisplayError(const char *error) {
    ClearScreen();
    DrawString(error,50,100,2,BLACK,RED);
}

void GUI::DrawIndicator(int x, int y, uint16_t color, bool clear, uint16_t bgcolor) {
    if(clear)
        Tft.fillRectangle(300,0,320,240,bgcolor);

    Tft.drawTraingle(x-5,y-5, x-5,y+5, x, y,color);
}
